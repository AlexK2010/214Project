#include "GroundControl.h"

GroundControl::GroundControl()
{

}

GroundControl::~GroundControl()
{
    cout<<"GroundControl destroyed"<<endl;
}

void GroundControl::update()
{
    //pure virtual function
}