#include "RocketIterator.h"

RocketIterator::RocketIterator()
{

}

RocketIterator::~RocketIterator()
{

}

void RocketIterator::first()
{

}

void RocketIterator::next()
{

}

bool RocketIterator::isDone()
{
    return true;
}

EngineObserver * RocketIterator::currentItem()
{
    return nullptr;
}

int RocketIterator::checkEngines()
{
    return 0;
}

bool RocketIterator::checkVacEngine()
{
    return true;
}
