#include "RocketObserver.h"

RocketObserver::RocketObserver()
{

}

RocketObserver::~RocketObserver()
{
    cout<<"RocketObserver destroyed"<<endl;
}

void RocketObserver::update()
{

}

bool RocketObserver::getState()
{
    return true;
}