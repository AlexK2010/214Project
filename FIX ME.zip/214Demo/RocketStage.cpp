#include "RocketStage.h"

RocketStage::RocketStage()
{

}

RocketStage::~RocketStage()
{
    cout<<"RocketStage destroyed"<<endl;
}

void RocketStage::breakEngine(long first,long second)
{
    //pure virtual function
}

