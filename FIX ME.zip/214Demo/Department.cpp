#include "Department.h"

Department::Department()
{

}

Department::~Department()
{
    cout<<"Department destroyed"<<endl;
}

void Department::notify()
{
    //pure virtual function
}