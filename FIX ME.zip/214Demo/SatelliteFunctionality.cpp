#include "SatelliteFunctionality.h"

SatelliteFunctionality::SatelliteFunctionality()
{

}

SatelliteFunctionality::~SatelliteFunctionality()
{
    cout<<"SatelliteFunctionality destroyed"<<endl;
}

void SatelliteFunctionality::execute(CollectionOfSatellites* collection, int time)
{
    //pure virtual function
}