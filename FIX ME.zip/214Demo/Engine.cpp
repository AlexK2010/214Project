#include "Engine.h"

Engine::Engine()
{

}

Engine::~Engine()
{

}

void Engine::attach()
{
    //pure virtual
}

void Engine::notify()
{
    //pure Virtual
}